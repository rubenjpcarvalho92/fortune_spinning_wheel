def start_ble():
    print("🔵 BLE iniciado (simulado)")
