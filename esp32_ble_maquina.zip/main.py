from config import DEVICE_NAME
from ble import start_ble

def main():
    print(f"Iniciando dispositivo: {DEVICE_NAME}")
    start_ble()

main()
